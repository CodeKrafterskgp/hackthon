import i from './i.png';
import ii from './ii.png';
import iii from './iii.png';
import iv from './iv.png';
import v from './v.png';

const imgData = [i, ii, iii, iv, v];

export default imgData;
